# 🚀 Deployment Guide for Tobly (Codex-Ready)

This project contains all Codex-applied production fixes including:
- AuthProvider & context safety
- Cleaned UI/UX with Tailwind
- Supabase integration
- Conversational AI onboarding
- GitHub Actions CI/CD for Netlify
- ESLint + Prettier + Testing setup

---

## 🔧 Initial Setup

```bash
# Unzip this folder
cd tobly_project

# Initialize Git (if not already)
git init
git remote add origin https://github.com/your-username/your-repo.git
git checkout -b main
```

---

## ✅ Commit & Push

```bash
git add .
git commit -m "feat: Codex production build with auth, routing, ai, and deployment"
git push -u origin main
```

---

## 🌍 GitHub Actions CI/CD

This project includes `.github/workflows/deploy.yml`.

Make sure you’ve added these secrets in GitHub:
- `NETLIFY_AUTH_TOKEN`
- `NETLIFY_SITE_ID`

CI will run on each push to `main` and auto-deploy to Netlify.

---

## 🧪 Dev Tools

```bash
npm install
npm run lint     # ESLint
npm run format   # Prettier
npm run dev      # Vite dev server
npm run build    # Production build
npm run test     # Vitest tests
```

---

## 🧾 Contact

Built and refined with Codex AI inside Bolt.